#! /bin/sh
# Load data in plain text files to tables
# Written by Li Yang

for f in student faculty class enrolled emp dept works flights aircraft employees certified suppliers parts catalog 
do
 echo "Inserting $f"
 mysql --local-infile lab -e "load data local infile '$f.txt' into table $f columns terminated by ',' optionally enclosed by '\"' lines terminated by '\r\n'"
done

