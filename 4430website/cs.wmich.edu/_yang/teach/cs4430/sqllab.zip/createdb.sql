--
-- 	Database Table Creation
--
--		This file will create the tables for use with the book 
--  Database Management Systems by Raghu Ramakrishnan and Johannes Gehrke.
--  It is run automatically by the installation script.
--
--	Version 0.1.0.0 2002/04/05 by: David Warden.
--	Copyright (C) 2002 McGraw-Hill Companies Inc. All Rights Reserved.
--
--
-- Modified by Li Yang

drop database lab;
create database lab;
use lab;
--
-- Now, add each table.
--
create table student(
	snum decimal(9) primary key,
	sname varchar(30),
	major varchar(25),
	level varchar(2),
	age int
	);
create table faculty(
	fid decimal(9) primary key,
	fname varchar(30),
	deptid decimal(2)
	);
create table class(
	cname varchar(40) primary key,
	meets_at varchar(20),
	room varchar(10),
	fid decimal(9),
	foreign key(fid) references faculty(fid)
	);
create table enrolled(
	snum decimal(9),
	cname varchar(40),
	primary key(snum,cname),
	foreign key(snum) references student(snum),
	foreign key(cname) references class(cname)
	);
create table emp(
	eid decimal(9) primary key,
	ename varchar(30),
	age int,
	salary decimal(10,2)
	);
create table dept(
	did decimal(2) primary key,
	dname varchar(20),
	budget decimal(10,2),
	managerid decimal(9),
	foreign key(managerid) references emp(eid)
	);
create table works(
	eid decimal(9),
	did decimal(2),
	pct_time decimal(3),
	primary key(eid,did),
	foreign key(eid) references emp(eid),
	foreign key(did) references dept(did)
	);
create table flights(
	flno decimal(4) primary key,
	origin varchar(20),
	destination varchar(20),
	distance decimal(6),
	departs datetime,
	arrives datetime,
	price decimal(7,2)
	);
create table aircraft(
	aid decimal(9) primary key,
	aname varchar(30),
	cruisingrange decimal(6)
	);
create table employees(
	eid decimal(9) primary key,
	ename varchar(30),
	salary decimal(10,2)
	);
create table certified(
	eid decimal(9),
	aid decimal(9),
	primary key(eid,aid),
	foreign key(eid) references employees(eid),
	foreign key(aid) references aircraft(aid)
	);
create table suppliers(
	sid decimal(9) primary key,
	sname varchar(30),
	address varchar(50)
	);
create table parts(
	pid decimal(9) primary key,
	pname varchar(40),
	color varchar(15)
	);
create table catalog(
	sid decimal(9),
	pid decimal(9),
	cost decimal(10,2),
	primary key(sid,pid),
	foreign key(sid) references suppliers(sid),
	foreign key(pid) references parts(pid)
	);


